"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

interface ProductFormProps {
  mode: "create" | "edit";
  productId?: string;
  defaultValues?: {
    title: string;
    description: string;
    price: number | string;
    quantity: number | null;
    image_link: string | null;
  };
}

function FieldLabel({ children }: { children: React.ReactNode }) {
  return (
    <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: "#475569" }}>
      {children}
    </label>
  );
}

const inputStyle = {
  background: "rgba(255,255,255,0.04)",
  border: "1px solid rgba(255,255,255,0.08)",
  color: "#e2e8f0",
  borderRadius: "0.625rem",
  padding: "0.6rem 0.875rem",
  fontSize: "0.875rem",
  width: "100%",
  outline: "none",
  transition: "border-color 0.15s",
};

export function ProductForm({ mode, productId, defaultValues }: ProductFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({
    title: defaultValues?.title ?? "",
    description: defaultValues?.description ?? "",
    price: defaultValues?.price ?? "",
    quantity: defaultValues?.quantity != null ? String(defaultValues.quantity) : "",
    image_link: defaultValues?.image_link ?? "",
  });
  const [preview, setPreview] = useState<string>(defaultValues?.image_link ?? "");

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setPreview(URL.createObjectURL(file));
    setUploading(true);
    setError("");
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: formData });
    const data = await res.json();
    setUploading(false);
    if (!res.ok) { setError(data.error ?? "Error al subir la imagen."); return; }
    setForm((prev) => ({ ...prev, image_link: data.url }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (uploading) return;
    setLoading(true);
    setError("");
    const url = mode === "create" ? "/api/products" : `/api/products/${encodeURIComponent(productId!)}`;
    const method = mode === "create" ? "POST" : "PUT";
    const payload: Record<string, unknown> = { title: form.title, description: form.description, price: form.price };
    if (form.quantity !== "") payload.quantity = parseInt(form.quantity, 10);
    if (form.image_link !== "") payload.image_link = form.image_link;
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error ?? "Error al guardar el producto.");
      setLoading(false);
      return;
    }
    router.push("/admin");
    router.refresh();
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="space-y-5 rounded-xl p-7 max-w-lg"
      style={{ background: "var(--card)", border: "1px solid rgba(255,255,255,0.06)" }}
    >
      {/* Título */}
      <div>
        <FieldLabel>Título</FieldLabel>
        <input
          id="title"
          name="title"
          value={form.title}
          onChange={handleChange}
          required
          placeholder="Ej: Camiseta azul"
          style={inputStyle}
          onFocus={(e) => (e.target.style.borderColor = "rgba(59,130,246,0.5)")}
          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.08)")}
        />
      </div>

      {/* Descripción */}
      <div>
        <FieldLabel>Descripción</FieldLabel>
        <textarea
          id="description"
          name="description"
          value={form.description}
          onChange={handleChange}
          rows={3}
          placeholder="Descripción del producto"
          style={{ ...inputStyle, resize: "vertical" }}
          onFocus={(e) => (e.target.style.borderColor = "rgba(59,130,246,0.5)")}
          onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.08)")}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        {/* Precio */}
        <div>
          <FieldLabel>Precio (USD)</FieldLabel>
          <input
            id="price"
            name="price"
            value={form.price}
            onChange={handleChange}
            type="number"
            step="0.01"
            min="0"
            required
            placeholder="0.00"
            style={inputStyle}
            onFocus={(e) => (e.target.style.borderColor = "rgba(59,130,246,0.5)")}
            onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.08)")}
          />
        </div>

        {/* Cantidad */}
        <div>
          <FieldLabel>Stock</FieldLabel>
          <input
            id="quantity"
            name="quantity"
            value={form.quantity}
            onChange={handleChange}
            type="number"
            step="1"
            min="0"
            placeholder="0"
            style={inputStyle}
            onFocus={(e) => (e.target.style.borderColor = "rgba(59,130,246,0.5)")}
            onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.08)")}
          />
        </div>
      </div>

      {/* Imagen */}
      <div>
        <FieldLabel>Imagen del producto</FieldLabel>
        <label
          className="relative rounded-xl cursor-pointer block text-center transition-all duration-150"
          style={{
            border: "2px dashed rgba(255,255,255,0.1)",
            background: "rgba(255,255,255,0.02)",
            padding: preview ? "1rem" : "2rem 1rem",
          }}
          onMouseEnter={(e) => ((e.currentTarget as HTMLLabelElement).style.borderColor = "rgba(59,130,246,0.4)")}
          onMouseLeave={(e) => ((e.currentTarget as HTMLLabelElement).style.borderColor = "rgba(255,255,255,0.1)")}
        >
          {preview ? (
            <div className="flex flex-col items-center gap-2">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={preview} alt="Vista previa" className="h-32 w-32 object-cover rounded-xl" style={{ border: "1px solid rgba(255,255,255,0.1)" }} />
              <span className="text-xs" style={{ color: "#475569" }}>{uploading ? "Subiendo..." : "Click para cambiar"}</span>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mx-auto" style={{ background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.2)" }}>
                <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="#3b82f6" strokeWidth={1.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
                </svg>
              </div>
              <p className="text-sm font-medium text-slate-400">Haz click para subir una foto</p>
              <p className="text-xs" style={{ color: "#334155" }}>JPG, PNG, WEBP · máx 10MB</p>
            </div>
          )}
          {uploading && (
            <div className="absolute inset-0 rounded-xl flex items-center justify-center" style={{ background: "rgba(6,11,24,0.8)" }}>
              <span className="text-sm font-medium" style={{ color: "#3b82f6" }}>Subiendo imagen...</span>
            </div>
          )}
          <input type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={handleFileChange} />
        </label>
      </div>

      {error && (
        <p className="text-xs px-3 py-2 rounded-lg" style={{ color: "#f87171", background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)" }}>
          {error}
        </p>
      )}

      <div className="flex gap-3 pt-1">
        <button
          type="submit"
          disabled={loading || uploading}
          className="flex-1 py-2.5 px-5 rounded-lg text-sm font-semibold text-white transition-all duration-150 disabled:opacity-50"
          style={{ background: "linear-gradient(135deg, #3b82f6, #2563eb)", boxShadow: "0 4px 15px rgba(59,130,246,0.25)" }}
        >
          {loading ? "Guardando..." : mode === "create" ? "Crear producto" : "Guardar cambios"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/admin")}
          className="px-5 py-2.5 rounded-lg text-sm font-medium transition-all duration-150"
          style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#64748b" }}
        >
          Cancelar
        </button>
      </div>
    </form>
  );
}
