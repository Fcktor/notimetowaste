"use client"
import { useCart } from "./CartProvider"

interface Product {
  id: string
  title: string
  price: number
  quantity: number | null
  image_link: string | null
  brand: string
  description?: string
}

export function ProductCard({ product }: { product: Product }) {
  const { addItem, setIsOpen } = useCart()
  const inStock = product.quantity == null || product.quantity > 0

  function handleImageClick() {
    if (!inStock) return
    addItem({
      id: product.id,
      title: product.title,
      price: product.price,
      image_link: product.image_link,
      maxStock: product.quantity,
    })
    setIsOpen(true)
  }

  return (
    <div className="store-card flex flex-col overflow-hidden">
      {/* Image */}
      <div
        className="relative overflow-hidden bg-gray-50 group/img"
        style={{ aspectRatio: "1/1", cursor: inStock ? "pointer" : "default" }}
        onClick={handleImageClick}
        title={inStock ? "Agregar al carrito" : undefined}
      >
        {product.image_link ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image_link}
            alt={product.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover/img:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-100">
            <svg width="40" height="40" fill="none" viewBox="0 0 24 24" stroke="#cbd5e1" strokeWidth={1}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </div>
        )}
        {inStock && (
          <div className="absolute inset-0 flex items-end justify-center pb-4 opacity-0 group-hover/img:opacity-100 transition-opacity duration-200 pointer-events-none" style={{ background: "linear-gradient(to top, rgba(7,16,48,0.45) 0%, transparent 60%)" }}>
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <svg width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              Agregar al carrito
            </span>
          </div>
        )}

        {/* Stock badge */}
        {!inStock && (
          <div className="absolute inset-0 flex items-center justify-center" style={{ background: "rgba(255,255,255,0.8)", backdropFilter: "blur(4px)" }}>
            <span className="text-xs font-semibold px-3 py-1 rounded-full" style={{ background: "#fee2e2", color: "#ef4444", border: "1px solid #fecaca" }}>
              Agotado
            </span>
          </div>
        )}

        {product.quantity != null && product.quantity > 0 && product.quantity <= 5 && (
          <div className="absolute top-3 left-3">
            <span className="text-[10px] font-bold px-2 py-1 rounded-full" style={{ background: "#fef3c7", color: "#d97706" }}>
              ¡Solo {product.quantity} en stock!
            </span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4 gap-3">
        <div>
          {product.brand && (
            <p className="text-[10px] font-semibold uppercase tracking-widest mb-1" style={{ color: "#94a3b8" }}>
              {product.brand}
            </p>
          )}
          <h3 className="text-sm font-semibold leading-snug" style={{ color: "#0f172a" }}>
            {product.title}
          </h3>
        </div>

        <div className="mt-auto flex items-center justify-between gap-2">
          <span className="text-xl font-bold" style={{ color: "#1d4ed8" }}>
            ${product.price}
          </span>
          <button
            onClick={handleImageClick}
            disabled={!inStock}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
            style={{
              background: inStock ? "linear-gradient(135deg, #1d4ed8, #3b82f6)" : "#e2e8f0",
              boxShadow: inStock ? "0 2px 12px rgba(59,130,246,0.35)" : "none",
              color: inStock ? "white" : "#94a3b8",
            }}
          >
            <svg width="13" height="13" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
            </svg>
            Agregar
          </button>
        </div>
      </div>
    </div>
  )
}
