"use client";
import Link from "next/link";
import { DeleteModal } from "./DeleteModal";

interface Product {
  id: string;
  title: string;
  price: number;
  availability: string;
  brand: string;
  quantity: number | null;
  image_link: string | null;
}

function EditIcon() {
  return (
    <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
    </svg>
  );
}

export function ProductTable({ products }: { products: Product[] }) {
  if (!products.length) {
    return (
      <div
        className="relative rounded-xl border p-16 text-center overflow-hidden"
        style={{ background: "var(--card)", borderColor: "rgba(59,130,246,0.15)", boxShadow: "0 0 30px rgba(59,130,246,0.05), inset 0 0 60px rgba(59,130,246,0.02)" }}
      >
        <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: "rgba(59,130,246,0.08)", border: "1px solid rgba(59,130,246,0.25)" }}>
          <svg width="24" height="24" fill="none" viewBox="0 0 24 24" stroke="#3b82f6" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 10V11" />
          </svg>
        </div>
        <p className="text-sm font-medium text-slate-400">No hay productos sincronizados</p>
        <p className="text-xs mt-1" style={{ color: "#334155" }}>Sincroniza desde Shopify o crea un producto nuevo</p>
      </div>
    );
  }

  return (
    <div
      className="relative rounded-xl overflow-hidden"
      style={{
        background: "var(--card)",
        border: "1px solid rgba(59,130,246,0.15)",
        boxShadow: "0 0 40px rgba(59,130,246,0.06), 0 1px 0 rgba(255,255,255,0.03) inset",
      }}
    >
      {/* Top glow line */}
      <div className="absolute top-0 left-0 right-0 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(59,130,246,0.4), rgba(6,182,212,0.4), transparent)" }} />

      <table className="w-full text-sm">
        <thead>
          <tr style={{ borderBottom: "1px solid rgba(59,130,246,0.1)", background: "rgba(59,130,246,0.04)" }}>
            {["Foto", "Producto", "Precio", "Stock", "Estado", "Marca", "Acciones"].map((col, i) => (
              <th
                key={col}
                className={`px-5 py-4 text-xs font-mono font-semibold uppercase tracking-[0.12em] ${i === 6 ? "text-right" : "text-left"}`}
                style={{ color: "#1e3a5f" }}
              >
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {products.map((p, i) => (
            <tr
              key={p.id}
              className="table-row-hover transition-all duration-200 group"
              style={{
                borderBottom: i < products.length - 1 ? "1px solid rgba(255,255,255,0.035)" : "none",
              }}
            >
              {/* Foto */}
              <td className="px-5 py-3.5">
                {p.image_link ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={p.image_link}
                    alt={p.title}
                    className="w-10 h-10 object-cover rounded-lg"
                    style={{ border: "1px solid rgba(59,130,246,0.2)" }}
                  />
                ) : (
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ background: "rgba(59,130,246,0.06)", border: "1px solid rgba(59,130,246,0.15)" }}
                  >
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="#3b82f6" strokeWidth={1.5}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 10V11" />
                    </svg>
                  </div>
                )}
              </td>

              {/* Título */}
              <td className="px-5 py-3.5">
                <span className="font-medium text-slate-200 group-hover:text-white transition-colors">{p.title}</span>
              </td>

              {/* Precio */}
              <td className="px-5 py-3.5">
                <span className="font-mono text-sm font-semibold text-glow-cyan" style={{ color: "#22d3ee" }}>
                  ${p.price}
                </span>
              </td>

              {/* Stock */}
              <td className="px-5 py-3.5">
                {p.quantity == null ? (
                  <span style={{ color: "#1e3a5f" }}>—</span>
                ) : (
                  <span
                    className="inline-flex items-center gap-1 text-xs font-mono font-semibold px-2.5 py-1 rounded-md"
                    style={
                      p.quantity === 0
                        ? { background: "rgba(239,68,68,0.08)", color: "#f87171", border: "1px solid rgba(239,68,68,0.2)" }
                        : p.quantity <= 5
                        ? { background: "rgba(245,158,11,0.08)", color: "#fbbf24", border: "1px solid rgba(245,158,11,0.2)" }
                        : { background: "rgba(59,130,246,0.08)", color: "#60a5fa", border: "1px solid rgba(59,130,246,0.2)" }
                    }
                  >
                    {p.quantity} uds
                  </span>
                )}
              </td>

              {/* Disponibilidad */}
              <td className="px-5 py-3.5">
                {p.quantity != null && p.quantity > 0 ? (
                  <span
                    className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-md"
                    style={{ background: "rgba(16,185,129,0.08)", color: "#34d399", border: "1px solid rgba(16,185,129,0.2)" }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 pulse-neon inline-block" style={{ color: "#34d399" }} />
                    En stock
                  </span>
                ) : (
                  <span
                    className="inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-md"
                    style={{ background: "rgba(239,68,68,0.08)", color: "#f87171", border: "1px solid rgba(239,68,68,0.2)" }}
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-red-400 inline-block" />
                    Sin stock
                  </span>
                )}
              </td>

              {/* Marca */}
              <td className="px-5 py-3.5">
                <span className="text-xs font-mono" style={{ color: "#334155" }}>{p.brand || "—"}</span>
              </td>

              {/* Acciones */}
              <td className="px-5 py-3.5">
                <div className="flex items-center justify-end gap-1.5">
                  <Link
                    href={`/admin/products/${encodeURIComponent(p.id)}`}
                    className="inline-flex items-center justify-center w-8 h-8 rounded-lg transition-all duration-150 group/btn"
                    style={{ color: "#3b82f6", background: "rgba(59,130,246,0.08)", border: "1px solid rgba(59,130,246,0.2)" }}
                    title="Editar"
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLAnchorElement).style.boxShadow = "0 0 12px rgba(59,130,246,0.4)";
                      (e.currentTarget as HTMLAnchorElement).style.borderColor = "rgba(59,130,246,0.5)";
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLAnchorElement).style.boxShadow = "none";
                      (e.currentTarget as HTMLAnchorElement).style.borderColor = "rgba(59,130,246,0.2)";
                    }}
                  >
                    <EditIcon />
                  </Link>
                  <DeleteModal productId={p.id} productTitle={p.title} quantity={p.quantity} />
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Bottom glow line */}
      <div className="h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(59,130,246,0.2), transparent)" }} />
    </div>
  );
}
